# CPTR 141: Project #1
## Student: Kaden Fairchild
## *Graded: November 1, 2019*
------
## Notes
* General solution needed for full credit.

## Solution Checklist
**E**: ✔
* Solves both the specific problem (a.k.a 7 from 4 and 9) and the
general problem (a.k.a 7 from m and n): ✔
* ...while also providing clear, efficient, and accurate instructions that are consistent with those given: ✔

**M**: ✔
* Solves the specific problem only, but does so using clear,
efficient, and accurate instructions consistent with those given: ✔

###### OR

* Solves both problems, but does not use clear and efficient
instructions (although the instructions are still accurate and
consistent): ✔

**R**: ✔
* A reasonable attempt was made: ✔

---
## TA GRADE: E