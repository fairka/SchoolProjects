/*************************************************************************
 *
 * Exercise: Exploring Variable Scope
 *
 * File Name: scope.cpp
 * Course:    CPTR 141
 */

#include <iostream> // for cin and cout
using namespace std;

int main() {
  
  int varOne;
  varOne = -1;

  {
  
  }

}
      