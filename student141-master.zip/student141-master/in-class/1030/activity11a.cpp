#include <iostream>
using namespace std;

void printMessage() {
  cout << "Welcome to C++." << endl;
  cout << "Learn the power of functions!" << endl;
}

int main() {
  cout << "Hello Programmer!" << endl;
  printMessage();
}
