/*************************************************************************
 *
 * In-Class Demonstration:  Compute the slope between two points.
 * 
 * File Name: slope.cpp
 * Course:    CPTR 141
 *
 */

#include <iostream>
using namespace std;

int main() {
   
   // define variables
   
   // prompt for input   
   
   // print out the slope
   
   return 0;
}
