/*************************************************************************
 *
 * In-Class Demonstration:  Prompt for two numbers and display their sum
 *
 * File Name: firstExample.cpp
 * Course:    CPTR 141
 *
 */

#include <iostream>
using namespace std;

int main() {  
}
