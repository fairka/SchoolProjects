/*************************************************************************
 *
 * Demonstration/Exercise: A factorial function
 *
 * File Name: factorial.cpp
 * Course:    CPTR 141
 */
#include "factorialFunction.h"
#define NDEBUG true
#include <cassert>
using namespace std;

// function definition
long factorial(int n) {
    assert(n > 0);
    long result = 1;
    while (n--) {
        result *= n;
    }
    return result;
}


