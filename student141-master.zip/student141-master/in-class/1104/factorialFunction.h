/*************************************************************************
 *
 * Demonstration/Exercise: A factorial function
 *
 * File Name: factorialFunction.h
 * Course:    CPTR 141
 */


using namespace std;

//Precondition:The integer n is > 0
//Postcondition: The function returns n!
long factorial(int n);



