/*************************************************************************
 *
 * In-Class Exercise:  A "hello world" program.
 *
 * File Name: hello.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */

#include <iostream>
using namespace std;

int main() {
   
    // print out some text (replace the question mark with your name)
    cout << "Hello World! My name is ? and this may be my first program in CPTR 141!\n";

    return 0;
}
