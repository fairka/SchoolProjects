#include <iostream>
using namespace std;

int main() {

  // variable for testing
  int x = 4, y = 5, z = 4;

  // put your condition inside the "if( )" statement
  if (x > y) {

    // this prints if the condition inside "if( )" is true
    cout << "true" << endl;

  } else {

    // this prints if it is false
    cout << "false" << endl;
  }

  return 0;
}
