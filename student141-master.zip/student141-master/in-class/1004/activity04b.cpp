#include <iostream>
using namespace std;

int main() {

  // assign two character variables
  char charOne = ' ';
  char charTwo = ' ';

  // print out their "sum"
  char sum = charOne + charTwo;
  cout << "sum = " << sum << endl;

  return 0;
}
