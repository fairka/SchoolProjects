#include <iostream>
using namespace std;

int main() {

  // test your code snippet here

  return 0;
}
