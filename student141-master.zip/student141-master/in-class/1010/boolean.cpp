/*************************************************************************
 *
 * In-Class Exercise:  This program gives us the results of various
 *                     combinatons of boolean and relational operators.
 *
 * File Name: boolean.cpp
 * Username:  ?
 * Username:  ?
 * Course:    CPTR 141
 * Date:      @@date@@
 *
 */

#include <iostream>
using namespace std;

int main() {

    // part 1 -- find the values of the given Boolean expressions
    /*
    cout << !false || (true && true);
    cout << !(false || true) && true;
    cout << (!false || true) && true;
    cout << !(false || true && true);
    cout << (5 && 7) + (!6);
    */

    // part 2 -- find the values of the given Boolean expressions with
    // relational operators

    int limit = 10;
    int count = 0;


    return 0;
}
