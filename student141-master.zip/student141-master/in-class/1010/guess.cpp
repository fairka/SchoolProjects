#include <ctime>   // form time command to use for random seed
#include <iostream>
using namespace std;

int main() {

  // pick a random number between 1 and 10
  srand(time(0));
  int theNumber = rand() % 10 + 1;

  // prompt for the user guesses
  int guessOne, guessTwo, guessThree;
  cout << "Enter your three guesses: ";
  cin >> guessOne >> guessTwo >> guessThree;

  // set a flag based on comparing the guesses with our number
    bool guessedCorrectly = false;
    if(guessOne == theNumber) {
        guessedCorrectly = true;
    }
    if(guessTwo == theNumber) {
        guessedCorrectly = true;
    }
    if(guessThree == theNumber) {
        guessedCorrectly = true;
    }
  // respond to the user
  if(guessedCorrectly ){
      cout << "You are correct!";
  }
  else {
      cout << "You did not guess correctly." << endl;
  }
  cout << "The number was " << theNumber << endl;

  return 0;
}
