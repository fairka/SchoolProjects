#include <iostream>
using namespace std;

int main() {
  int numCredits = 194;
  double majorGPA = 2.9;
  double overallGPA = 2.1;
  if ( /* missing Boolean expression> */ ) {
    cout << "Congratulations!" << endl;
    cout << "You seem to meet the criteria for graduation." << endl;
  } else {
    cout << "Sorry!" << endl;
    cout << "You do not meet all the criteria for graduation." << endl;
  }
}
