int main() {
  const int MAX_NUM_SCORES = 3;
  int scores[MAX_NUM_SCORES] = {0, 0, 0};
  int dummy = 2;

  for (int i = 0; i <= MAX_NUM_SCORES; i++) {
    scores[i] = 1;
  }
}