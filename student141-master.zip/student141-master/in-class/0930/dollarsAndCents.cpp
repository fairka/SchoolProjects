/*************************************************************************
 *
 * In-Class Demonstration:  Formatting the Output of a Floating-Point Var
 *
 * File Name: dollarsAndCents.cpp
 * Course:    CPTR 141
 *
 */

#include <iostream>
#include <iomanip>
using namespace std;

int main() {

   // define variables for user input
   double money;
   int children;

   // get the numbers
   cout << "How much money do you have in your pocket? $";
   cin >> money;
   cout << "How many children do you have? ";
   cin >> children;
   //get rid of the rounding
   int cents = 100*money;
   int leftover = cents % children;
   double leftover_amount = leftover / 100.0;
   double amount = (cents / children) / 100.0;
   // print out the results
   cout << fixed << setprecision(2) << endl;
   cout << "Give each child $" << (money / children);
   cout << " and keep $" << leftover_amount << " for yourself." << endl;

   return 0;
}
