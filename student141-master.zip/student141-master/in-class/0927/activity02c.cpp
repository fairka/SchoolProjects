#include <iostream>
#include <string>
using namespace std;

int main() {
   int a = 2;
   int b = 3;

   a += b;
   cout << a << " " << b << endl;
   b *= a -2;
   cout << a << " " << b;
   
}
