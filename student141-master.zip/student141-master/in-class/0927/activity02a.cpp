#include <iostream>
using namespace std;

int main() {
  cout << 16 + 3 << endl;   
  cout << 16 - 3 << endl;
  cout << 16 * 3 << endl;   
  cout << 16 / 3 << endl;   
  cout << 16 % 3 << endl;   
}
