/*************************************************************************
 *
 * In-Class Exercise: Using Vectors to Store Prices and More
 *
 * File Name: trolls.cpp
 * Course:    CPTR 141
 */

#include <iostream> // for cin and cout
#include <vector>   // for vectors
#include<string>
using namespace std;

/*=================================== << ": ";
 * Main program
 */

int main() {

  // define your variables here
  const int NUM = 3;
  vector<string> storeName(NUM);
  vector<double> Prices(NUM);


  // loop to collect information
  for (int i = 0; i < NUM; i++) {
      cout << "Enter store " << (i+1) << ": ";
      if(i !=0){
          getline(cin,storeName.at(i));
      }
      getline(cin,storeName.at(i));
      cout << "Enter price ";
      cout <<  i+1 << ": ";
      cin >> Prices.at(i);

  }

  // loop to print out prices
  double smallestPrice = Prices.at(0);
  int smallestIndex = 0;
  for (int i = 1; i < NUM; i++) {
       if(Prices.at(i) < smallestPrice){
           smallestPrice = Prices.at(i);
           smallestIndex = i;
       }
  }
  cout << "The cheapest price is $" << smallestPrice << " at " << storeName.at(smallestIndex) << endl;
  return 0;
}