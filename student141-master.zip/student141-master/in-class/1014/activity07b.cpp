#include <iostream>
#include <iomanip>
using namespace std;

int main() {
  string word;
  char doAgain = 'y';
  while(doAgain == 'y') {
      cout << "Enter a word: ";
      cin >> word;
      cout << "The first letter is " << word.at(0) << endl;
      cout << "Type 'y' to enter another word, anything else to quit. ";
      cin >> doAgain;

  }
  cout << "Done!" << endl;
  cout << endl;
}
