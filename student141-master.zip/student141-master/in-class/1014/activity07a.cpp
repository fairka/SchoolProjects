#include <iostream>
#include <string>
using namespace std;

int main() {
  string name;
  cout << "Enter your name: ";
  cin >> name;
  int x = 0;
  while (x < 23) {
    cout << name << x << endl;
    x = x + 1;
  }
  cout << "Nice to meet you!" << endl;
}
