#include <iostream>
using namespace std;

int main() {
  int countdown = 100;
  while (countdown > 0) {
    cout << countdown << endl;
  }
}
