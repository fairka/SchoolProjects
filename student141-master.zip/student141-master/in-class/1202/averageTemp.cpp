/*************************************************************************
 *
 * In-Class Demo: Reading and averaging temperatures from a file
 *
 * File Name: averageTemp.cpp
 * Course:    CPTR 141
 *
 */

#include <fstream>  // for file input/output
#include <iostream> // for cin and cout
#include <sstream>  // for string stream
#include <string>   // for strings
using namespace std;

int main() {

  // declare variables
  ifstream fin;
  string stateName, line;

  // open the file
  fin.open("temps.txt");

  // read a line at a time and process it
  while(getline(fin,line)){
      istringstream stringIn(line);
      int sum = 0, count = 0, value;
      stringIn >> stateName;
     
      while(stringIn >> value){
          sum += value;
          count++;
      }
      cout << "State: " << stateName 
      << ", Average Temp: "
      << static_cast<double>(sum)/count 
      << endl;
  }

}
