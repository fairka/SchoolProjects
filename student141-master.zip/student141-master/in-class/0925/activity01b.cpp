#include <iostream>
using namespace std;

int main() {

  cout <<
  cout <<
  cout <<
}
