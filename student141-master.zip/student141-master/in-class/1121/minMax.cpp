/*************************************************************************
 *
 * In-Class Exercise and Demo: Reading and Writing Files
 *
 * File Name: minMax.cpp
 * Course:    CPTR 141
 *
 */

#include <climits>  // for min/max integer
#include <fstream>  // for file input/output
#include <iostream> // for cin and cout
using namespace std;

int main() {

  // declare variables (you may need to add)
  int min = INT_MAX;
  int max = INT_MIN;
  int count = 0;

  // open the file

  // read the numbers

  // print the results
  cout << "Smallest: " << min << endl;
  cout << "Largest: " << max << endl;
  cout << "Count: " << count << endl;
}
