/*************************************************************************
 *
 * In-Class Demonstration: Generate a random addition problem with a given
 *                         number of digits
 *
 * File Name: addition.cpp
 * Course:    CPTR 141
 *
 */

#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

int main() {

   // define variables
   int seed, digits, addendOne, addendTwo;

   // prompt for and set seed
   cout << "Enter random number seed: ";
   cin >> seed;
   srand(seed);

   // prompt for and get number of digits
   cout << "Number of digits: ";
   cin >> digits;

   // generate random numbers
   addendOne = rand()%static_cast<int> (9 * pow(10, digits -1)) + pow(10,digits-1);
   addendTwo = rand()%static_cast<int> (9 * pow(10, digits -1)) + pow(10,digits-1);

   // print out problem
   cout << endl;
   cout << setw(8) << addendOne << endl;
   cout << "+" << setw(7) << addendTwo << endl;
   cout << "--------" << endl;
   return 0;
}
