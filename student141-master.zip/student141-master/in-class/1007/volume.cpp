/*************************************************************************
 *
 * In-Class Exercise:  Compute the volumn of a right circular cylindar 
 *                     of a given radius and height
 * 
 * File Name: volume.cpp
 * Course:    CPTR 141
 *
 */

#include <iostream>
#include <cmath>
using namespace std;

int main() {
   
   // define constant
   
   // define variables
   
   // prompt for input
   
   // print out the volume (use the pow function)

   return 0;
}
