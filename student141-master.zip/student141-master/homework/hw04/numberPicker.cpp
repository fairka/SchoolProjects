/*************************************************************************
 *
 * hw04: A program to prompt the user for five numbers and then randomly
 *       pick one of them.
 *
 * File Name: numberPicker.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */

#include <iostream>
using namespace std;

int main() {
  int randomSeed;
  int firstNum, secondNum, thirdNum, fourthNum, fifthNum;
  int chosen;

  cout << "Enter Random Seed: ";
  cin >> randomSeed;
  cout << endl;

  cout << "Enter First Number: ";
  cin >> firstNum;
  cout << "Enter Second Number: ";
  cin >> secondNum;
  cout << "Enter Third Number: ";
  cin >> thirdNum;
  cout << "Enter Fourth Number: ";
  cin >> fourthNum;
  cout << "Enter Fifth Number: ";
  cin >> fifthNum;

  srand(randomSeed);
  chosen = rand() % 5 + 1;
  cout << endl;

  if (chosen == 1) {
    cout << "I choose " << firstNum;
  } else if (chosen == 2) {
    cout << "I choose " << secondNum;
  } else if (chosen == 3) {
    cout << "I choose " << thirdNum;
  } else if (chosen == 4) {
    cout << "I choose " << fourthNum;
  } else if (chosen == 5) {
    cout << "I choose " << fifthNum;
  }
  cout << endl;
  return 0;
}
