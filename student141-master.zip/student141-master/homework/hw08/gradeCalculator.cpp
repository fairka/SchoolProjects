/****************************************************************************
 *
 * hw08: Calculate the average for a user-entered number of grades
 *
 * File Name:  gradeCalculator.cpp
 * Name:       ?
 * Course:     CPTR 141
 *
 */

#include <iomanip>  // for format output
#include <iostream> // for cout and cin
#include <vector>   // for vectors
using namespace std;

int main() {
  vector<double> grade(0);

  // opening prompt
  cout << "Enter a score between 0 and 100 on each line." << endl;
  cout << "Enter a negative number to finish." << endl;
  cout << endl;

  /* Your Code Here */
  double input;
  int inputCounter = 1;
  do {
    cout << "Grade #" << inputCounter << ": ";
    cin >> input;
    if (input > 100) {
      cout << "Error!  Grades may not be more than 100." << endl;
    } else if (input >= 0 && input <= 100) {
      grade.push_back(input);
      ++inputCounter;
    }
  } while (input >= 0);

  double sum = 0;
  for (int i = 0; i < grade.size(); i++) {
    sum = grade.at(i) + sum;
  }
  double average = sum / grade.size();
  if (average >= 0) {
    cout << "Your avearge is: " << setprecision(2) << fixed << average << endl;
  } else {
    cout << "No grades were entered." << endl;
  }

  return 0;
}
