/****************************************************************************
 *
 * hw07: Implement a program to find prime numbers up to a user define value.
 *
 * File Name:  prime.cpp
 * Name:       ?
 * Course:     CPTR 141
 *
 */

#include <iostream> // for cout and cin
using namespace std;

int main() {
  int upperLimit, i, j;

  cout << "Premium Prime Printer (twice the primes, half the time)" << endl;
  cout << "=======================================================" << endl;

  do {
    cout << "Enter Integer Upper Limit (3 or more): ";
    cin >> upperLimit;
    if (upperLimit < 3) {
      cout << "Error!  Please enter a number bigger than 2." << endl;
    }
  } while (upperLimit < 3);
  cout << endl;

  for (i = 2; i <= upperLimit; i++) {
    for (j = 2; j <= (i / j); j++)
      if (!(i % j))
        break;
    if (j > (i / j))
      cout << i << " is a prime number." << endl;
  }

  return 0;
}
