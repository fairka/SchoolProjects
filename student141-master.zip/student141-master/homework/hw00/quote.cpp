/*************************************************************************
 *
 * hw00:  A program to output an inspiring quote
 *
 * File Name: quote.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */

#include <iostream>
using namespace std;

int main() {

  // insert your code here
  cout << "It should be mandatory" << endl;
  cout << "  that you" << endl;
  cout << "    understand computer science." << endl;
  cout << endl;
  cout << "- will.i.am" << endl;

  // ctrl + shift + i
  return 0;
}
