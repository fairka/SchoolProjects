/*************************************************************************
 *
 * hw05: An implementation of a decision tree.
 *
 * File Name: decisionTree.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */

#include <iostream>
using namespace std;

int main() {
  int weather;
  int duration;
  int books;
  string bus = "You had better ride the bus to school.";
  string walk = "You should walk to school.";

  /* YOUR CODE GOES HERE */
  cout << "Should you Walk or Ride?  Let's find out!" << endl;
  cout << "a. What is the weather like?" << endl
       << "   1 = Hot and Dry" << endl
       << "   2 = Cool and Dry" << endl
       << "   3 = Rainy" << endl;
  cout << "Enter Choice: ";
  cin >> weather;

  if (weather == 1) {
    cout << "b. How much time do you have, in minutes? ";
    cin >> duration;
    if (duration < 30) {
      cout << endl << bus << endl;
    } else {
      cout << "c. How many books do you have? ";
      cin >> books;
      if (books <= 2) {
        cout << endl << walk << endl;
      } else {
        cout << endl << bus << endl;
      }
    }
  }
  if (weather == 2) {
    cout << "b. How much time do you have, in minutes? ";
    cin >> duration;
    if (duration < 20) {
      cout << endl << bus << endl;
    } else {
      cout << "c. How many books do you have? ";
      cin >> books;
      if (books <= 4) {
        cout << endl << walk << endl;
      } else {
        cout << endl << bus << endl;
      }
    }
  }
  if (weather == 3) {
    cout << endl << bus << endl;
  }

  return 0;
}
