/****************************************************************************
 *
 * hw16: Checking for Lo Shu Magic Squares
 *
 * File Name: magicSquare.cpp
 * Name:      Kaden
 * Course:    CPTR 141
 *
 */

#include "magicSquare.h"

bool isLoShu(int square[][SIZE], int SIZE) {

  if (square[0][0] + square[0][1] + square[0][2] == 15 &&
      square[1][0] + square[1][1] + square[1][2] == 15 &&
      square[2][0] + square[2][1] + square[2][2] == 15 &&

      square[0][0] + square[1][0] + square[2][0] == 15 &&
      square[0][1] + square[1][1] + square[2][1] == 15 &&
      square[0][2] + square[1][2] + square[2][2] == 15 &&

      square[0][0] + square[1][1] + square[2][2] == 15 &&
      square[0][2] + square[1][1] + square[2][0] == 15) {
    return true;
  } else {
    return false;
  }
}