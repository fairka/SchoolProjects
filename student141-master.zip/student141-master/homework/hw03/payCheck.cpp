/*************************************************************************
 *
 * hw04: Compute the gross pay, withholdings, and net pay for an
 *       employee given the number of hours worked and number of
 *       dependents.
 *
 * File Name: paycheck.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */

#include <iomanip>
#include <iostream>
using namespace std;

int main() {
  double hours;
  double const fixedRate = 18.50;
  double dependents;
  double const OT_HOURS = 40;
  double grossPay;
  double withholdings;
  double netPay;
  double const socialSecurity = .062;
  double const medicare = .0145;

  cout << "Enter the number of hours worked: ";
  cin >> hours;
  cout << "Enter the number of dependents: ";
  cin >> dependents;
  double incomeTax = .15 - (dependents * .01);

  // compute gross pay
  if (hours < OT_HOURS) {
    grossPay = hours * fixedRate;
  } else {
    grossPay = (40 * fixedRate) + (hours - 40) * 27.75;
  }
  cout << endl;
  cout << "Your gross pay is: $" << fixed << setprecision(2) << grossPay
       << endl;
  withholdings = grossPay * (socialSecurity + medicare + incomeTax) + 10;
  cout << "The withholdings are: $" << fixed << setprecision(2) << withholdings
       << endl;
  netPay = grossPay - withholdings;
  cout << "So that your net pay is: $" << netPay << endl;
  
  return 0;
}
