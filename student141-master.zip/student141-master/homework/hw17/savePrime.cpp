/****************************************************************************
 *
 * hw17: Read a file and output any prime numbers to another file
 *
 * File Name: savePrime.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */
#include <fstream>
#include <iostream>
#include <string>
using namespace std;

// prototype
bool isPrime(int number);

int main() {
  string fileName;
  int fileData;
  bool improperEntry = false;

  /* YOUR CODE GOES HERE */
  cout << "Input File: ";
  cin >> fileName;

  ofstream fout;
  ifstream fin;

  fout.open("primes.txt");
  if (!fout.is_open()) {
    cerr << "Error! Could not open file." << endl;
    return 1;
  }

  fin.open(fileName);
  if (!fin.is_open()) {
    cerr << "Error! Could not open file." << endl;
    return 1;
  }

  while (!fin.eof()) {
    fin >> fileData;

    if (fin.fail()) {
      fin.clear();
      fin.ignore(100, '\n');
      cerr << "Error! Invalid number found." << endl;
      improperEntry = true;
    } else {
      improperEntry = false;
    }
    if (isPrime(fileData) && !improperEntry) {
      fout << fileData << endl;
    }
  }
  cout << "File succesfully processed." << endl;
}

bool isPrime(int number) {
  // check for prime
  for (int i = 2; i <= number - 1; i++) {
    // number is not prime if n/i has no remainder
    if ((number % i) == 0) {
      return false;
    }
  }
  return true;
}
