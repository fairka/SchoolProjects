/****************************************************************************
 *
 * hw12:  Functions for tracking quiz grades in CPTR 141
 *
 * File Name:  gradeBookFunctions.h
 * Name:       ?
 * Course:     CPTR 141
 *
 */

#include "gradeBookFunctions.h"
#include <iostream>
#include <string>
#include <vector>
using namespace std;

/*=====================================================================
 * DECLARE AND INITALIZE GLOBALS HERE
 */
vector<char> quizScores;
const int NUM_QUIZZES = 8;
const int MIN_PASS_FOR_A = 8;
const int MIN_E_FOR_A = 4;
const int MIN_PASS_FOR_B = 7;
const int MIN_E_FOR_B = 2;
const int MIN_PASS_FOR_C = 5;
const int MIN_PASS_FOR_D = 4;
int gradeNumber = 1;

/*=====================================================================
 * FUNCTION: getScore(string message)
 *   Prompts for a new quiz score using the string "message" and
 *   validates it before storing it in the global "quizScores" vector.
 *   Also makes sure that we have no more than NUM_QUIZZES quiz scores.
 *    - Precondition: none
 *    - Postcondition: returns false if the score vector is full (already
 *      at NUM_QUIZZES) or an invalid grade is entered, otherwise an E,
 *      M, R, or N is pushed onto "quizScores" and true is returned
 */
bool getScore(string message) {
  if (quizScores.size() >= NUM_QUIZZES) {

    return false;

  } else {

    cout << "  - grade " << gradeNumber << ": ";
    cin >> message;
    gradeNumber++;

    if (message == "E") {

      quizScores.push_back('E');
      return true;

    } else if (message == "M") {

      quizScores.push_back('M');
      return true;

    } else if (message == "R") {

      quizScores.push_back('R');
      return true;

    } else if (message == "N") {

      quizScores.push_back('N');
      return true;
    }
  }

  return false;
}

/*=====================================================================
 * FUNCTION: calcGrade()
 *   Calculates and returns the letter grade ('A', 'B', 'C', 'D', or
 *   'F') from the global vector of homework scores as defined by the
 *   global constants: MIN_PASS_FOR_A, MIN_PASS_FOR_B, MIN_PASS_FOR_C,
 *   MIN_PASS_FOR_D, MIN_E_FOR_A, and MIN_E_FOR_B.
 *     - Precondition: the global "quizScores" vector must have at least
 *       one entry
 *     - Post condition: the correct grade letter is returned
 */
char calcGrade() {

  int eCounter = 0;
  int passCounter = 0;

  if (quizScores.size() > 0) {
    for (int i = 0; i < quizScores.size(); i++) {
      if (quizScores.at(i) == 'E') {
        eCounter++;
        passCounter++;
      } else if (quizScores.at(i) == 'M') {
        passCounter++;
      }
    }
  }

  if (passCounter >= MIN_PASS_FOR_A && eCounter >= MIN_E_FOR_A) {
    return 'A';
  } else if (passCounter >= MIN_PASS_FOR_B && eCounter >= MIN_E_FOR_B) {
    return 'B';
  } else if (passCounter >= MIN_PASS_FOR_C) {
    return 'C';
  } else if (passCounter >= MIN_PASS_FOR_D) {
    return 'D';
  }
  return 'F';
}

/*=====================================================================
 * FUNCTION: changeScore(int index, char newScore)
 *   Updates quizScores at the given index to a newScore if the newScore
 *   is valid (E, M, R, or N) and better than the current score.
 *     - Precondition: the global "quizScores" vector must have an entry at
 *       the given index
 *     - Postcondition: if newScore is valid and higher, the entry in the
 *       global "quizScores" will be updated and true returned, otherwise
 *       false is returned
 */
bool changeScore(int index, char newScore) {
  if (index > (quizScores.size() - 1)) {
    return false;
  }
  if (quizScores.at(index) == 'E' || quizScores.at(index) == 'M' ||
      quizScores.at(index) == 'R' || quizScores.at(index) == 'N') {
    if (newScore != 'E' && newScore != 'M' && newScore != 'R' &&
        newScore != 'N') {

      return false;

    } else {
      if (quizScores.at(index) == 'E') {

      } else if (quizScores.at(index) == 'M' && newScore == 'E') {
        quizScores.at(index) = 'E';
        return true;
      } else if (quizScores.at(index) == 'R' &&
                 (newScore == 'E' || newScore == 'M')) {
        if (newScore == 'E') {
          quizScores.at(index) = 'E';
          return true;
        } else if (newScore == 'M') {
          quizScores.at(index) = 'M';
          return true;
        }
      } else if (quizScores.at(index) == 'N' &&
                 (newScore == 'E' || newScore == 'M' || newScore == 'R')) {
        if (newScore == 'E') {
          quizScores.at(index) = 'E';
          return true;
        } else if (newScore == 'M') {
          quizScores.at(index) = 'M';
          return true;
        } else if (newScore == 'R') {
          quizScores.at(index) = 'R';
          return true;
        }
      }
    }
  }
  return false;
}