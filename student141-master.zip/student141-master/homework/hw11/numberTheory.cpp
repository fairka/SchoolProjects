/****************************************************************************
 *
 * hw11:  A library of simple functions
 *
 * File Name:  numberTheory.cpp
 * Name:       Kaden Fairchild
 * Course:     CPTR 141
 *
 */
#include <assert.h>

bool divisible(int num1, int num2) {
  assert(num1 >= 0 && num2 >= 0);
  bool answer;
  if (num1 % num2 != 0) {
    answer = false;
  } else {
    answer = true;
  }
  return answer;
}

int gcd(int num1, int num2) {
  assert(num1 >= 0 && num2 >= 0);
  if (num2 == 0)
    return num1;
  return gcd(num2, num1 % num2);
}

int gcd(int num1, int num2, int num3) {
  assert(num1 >= 0 && num2 >= 0 && num3 >= 0);
  int gcd2 = gcd(num1, num2);
  if (num3 == 0)
    return gcd2;
  return gcd(num3, gcd2 % num3);
}
