/*************************************************************************
 *
 * hw14: Find the perimeter of several different types of figures
 *
 * File Name: perimeter.h
 * Name:      ???
 * Course:    CPTR 141
 *
 */

extern const double PI;

double findPerimeter(double length, int sides);
double findPerimeter(double radius);
