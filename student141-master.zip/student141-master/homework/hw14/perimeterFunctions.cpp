/*************************************************************************
 *
 * hw14: Find the perimeter of several different types of figures
 *
 * File Name: perimeterFunctions.cpp
 * Name:      ???
 * Course:    CPTR 141
 *
 */

#include "perimeterFunctions.h"

const double PI = 3.141592653689;

double findPerimeter(double length, int sides) {
  double perimeter;
  perimeter = length * sides;
  return perimeter;
}

double findPerimeter(double radius) {
  double perimeter;
  perimeter = 2 * PI * radius;
  return perimeter;
}
