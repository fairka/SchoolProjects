/****************************************************************************
 *
 * hw06: Prompt the user for a word and then check it for double characters.
 *
 * File Name: double.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */

#include <iostream> // for cout and cin
#include <string>   // for string commands
using namespace std;

int main() {
  string word;
  int letterCount = 1;
  int doubleCheck = 0;
  char previousValue;
  /* YOUR CODE GOES HERE */

  cout << "Welcome to the DoubleChecker(TM) word checker" << endl;
  cout << "=============================================" << endl;
  cout << "Enter a word to check: " << endl;
  cin >> word;

  while (letterCount < word.size()) {
    previousValue = word.at(letterCount - 1);

    if (previousValue == word.at(letterCount)) {
      doubleCheck = 1;
    }
    letterCount += 1;
  }
  if (doubleCheck == 1) {
    cout << "There are double characers in the word " << word << "." << endl;

  } else {
    cout << "I could not find any double characters." << endl;
  }

  return 0;
}
