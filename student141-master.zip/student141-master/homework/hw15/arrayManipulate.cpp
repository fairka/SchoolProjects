/****************************************************************************
 *
 * Asgn.15:  A library of array functions
 *
 * File Name: arrayManipulate.cpp
 * Name:      ?
 * Course:    CPTR 141
 *
 */

#include "arrayManipulate.h"
#include <cassert>

void square(int array[], int length) {
  for (int i = 0; i < length; i++) {
    array[i] *= array[i];
  }
}

void divdeBy(int array[], int length, int dividedBy) {
  for (int i = 0; i < length; i++) {
    array[i] /= dividedBy;
  }
}

void accumulate(int array[], int length) {
  for (int i = 0; i < length; i++) {
    (array[i] += array[i - 1]);
  }
}

void reverse(int array[], int length) {
  int temp;
  for (int i = 0; i < length / 2; ++i) {
    temp = array[i];
    array[i] = array[length - i - 1];
    array[length - i - 1] = temp;
  }
}